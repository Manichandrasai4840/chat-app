package com.example.new_project1;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
